<header className="relative h-56 w-full overflow-hidden">
  <img
    src={`https://images.pexels.com/photos/2901209/pexels-photo-2901209.jpeg?auto=compress&cs=tinysrgb&w=1200&h=400&fit=crop`}
    alt={"dest"}
    className="absolute inset-0 h-full w-full object-cover"
  />
</header>